function T = fkine(S,M,q,frame)
    % Your code here
end