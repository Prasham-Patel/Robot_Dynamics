function J = jacob0(S,q)
% Your code here
end