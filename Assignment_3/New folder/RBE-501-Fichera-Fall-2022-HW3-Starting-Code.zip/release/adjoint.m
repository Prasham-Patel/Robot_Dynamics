function Vb = adjoint(Va,T)
    % Your code here
end

