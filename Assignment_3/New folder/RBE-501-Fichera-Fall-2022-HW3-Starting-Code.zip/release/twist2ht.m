function T = twist2ht(S,theta)
% Your code here
end