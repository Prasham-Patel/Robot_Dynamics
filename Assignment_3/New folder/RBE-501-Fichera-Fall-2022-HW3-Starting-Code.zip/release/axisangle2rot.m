function R = axisangle2rot(omega,theta)
% Your code here
end