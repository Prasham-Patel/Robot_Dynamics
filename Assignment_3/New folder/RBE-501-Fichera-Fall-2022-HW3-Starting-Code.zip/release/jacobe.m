function J_v = jacobe(S,M,q)    
% Your code here
end
