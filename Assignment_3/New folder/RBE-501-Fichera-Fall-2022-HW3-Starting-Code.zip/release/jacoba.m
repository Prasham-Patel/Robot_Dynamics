function J_a = jacoba(S,M,q)    
% Your code here
end